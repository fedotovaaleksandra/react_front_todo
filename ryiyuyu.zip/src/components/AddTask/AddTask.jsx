import { useState } from "react";
import ErrorMessage from "../ErrorMessage/ErrorMessage";
import "./style.scss";

const AddTask = ({ text, addTask, showError, deleteTask }) => {
  const [ addText, setAddText ] = useState(text);

  const  addNewTask = async () => {
    
  }
} 